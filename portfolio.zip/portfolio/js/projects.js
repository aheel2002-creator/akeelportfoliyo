/* =========================================================
   projects.js
   ---------------------------------------------------------
   EDIT THIS FILE to change your projects and blog posts.
   Everything else on the page is layout — this is content.
   ========================================================= */

const PROJECTS = [
  {
    icon: "🔎",
    title: "Network Scanner",
    tag: "network",
    desc: "Python tool that sweeps a subnet, finds live hosts, maps open ports and fingerprints services.",
    stack: ["Python", "Scapy", "Nmap"],
    github: "https://github.com/",
    demo: ""
  },
  {
    icon: "🔐",
    title: "Password Manager",
    tag: "security",
    desc: "Local vault with AES-encrypted storage, a master-key unlock and a strength checker for new entries.",
    stack: ["Python", "SQLite", "Cryptography"],
    github: "https://github.com/",
    demo: ""
  },
  {
    icon: "📊",
    title: "Security Dashboard",
    tag: "web",
    desc: "Web dashboard that reads log files and charts failed logins, alerts and traffic spikes in one view.",
    stack: ["JavaScript", "Chart.js", "Flask"],
    github: "https://github.com/",
    demo: ""
  },
  {
    icon: "🛡️",
    title: "Vulnerability Scanner",
    tag: "security",
    desc: "Checks a target site against common OWASP Top 10 issues and produces a plain-language report.",
    stack: ["Python", "Requests", "OWASP"],
    github: "https://github.com/",
    demo: ""
  },
  {
    icon: "📡",
    title: "Packet Analyzer",
    tag: "network",
    desc: "Captures live traffic, decodes protocols and flags anything that looks like a scan or flood.",
    stack: ["Python", "Wireshark", "Scapy"],
    github: "https://github.com/",
    demo: ""
  },
  {
    icon: "🖥️",
    title: "Portfolio Website",
    tag: "web",
    desc: "This site — a single-page portfolio built from scratch with no frameworks and no build step.",
    stack: ["HTML", "CSS", "JavaScript"],
    github: "https://github.com/",
    demo: "#home"
  }
];

const POSTS = [
  {
    date: "Coming soon",
    read: "6 min read",
    title: "Introduction to ethical hacking",
    desc: "What the phases of a penetration test actually look like, and why permission is the whole job."
  },
  {
    date: "Coming soon",
    read: "5 min read",
    title: "Top Linux commands worth memorising",
    desc: "The handful of terminal commands I reach for every single day, with real examples."
  },
  {
    date: "Coming soon",
    read: "8 min read",
    title: "OWASP Top 10, explained simply",
    desc: "Ten of the most common web vulnerabilities, each with a plain-language example and a fix."
  },
  {
    date: "Coming soon",
    read: "7 min read",
    title: "A practical Nmap guide",
    desc: "Scan types, timing options and how to read the output without drowning in flags."
  },
  {
    date: "Coming soon",
    read: "6 min read",
    title: "Network security basics",
    desc: "Firewalls, segmentation and encryption — the three ideas most small networks are missing."
  },
  {
    date: "Coming soon",
    read: "4 min read",
    title: "Setting up a home lab",
    desc: "Building a safe practice environment with virtual machines so you can break things legally."
  }
];

/* ---------- render projects ---------- */
function renderProjects() {
  const host = document.getElementById("projects");
  if (!host) return;

  host.innerHTML = PROJECTS.map(p => `
    <article class="card proj reveal" data-tag="${p.tag}">
      <div class="proj__top">
        <span>${p.icon}</span>
        <span class="proj__tag">${p.tag}</span>
      </div>
      <div class="proj__body">
        <h3>${p.title}</h3>
        <p>${p.desc}</p>
        <div class="proj__stack">${p.stack.map(s => `<span>${s}</span>`).join("")}</div>
        <div class="proj__links">
          <a href="${p.github}" target="_blank" rel="noopener">GitHub</a>
          ${p.demo ? `<a href="${p.demo}" target="_blank" rel="noopener">Live demo</a>` : ""}
        </div>
      </div>
    </article>
  `).join("");
}

/* ---------- render blog posts ---------- */
function renderPosts() {
  const host = document.getElementById("blogList");
  if (!host) return;

  host.innerHTML = POSTS.map(b => `
    <article class="card post reveal">
      <p class="post__meta">${b.date} · ${b.read}</p>
      <h3>${b.title}</h3>
      <p>${b.desc}</p>
      <span class="post__more">Read the write-up</span>
    </article>
  `).join("");
}

renderProjects();
renderPosts();
