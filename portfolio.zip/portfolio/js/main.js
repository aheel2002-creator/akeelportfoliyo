/* =========================================================
   main.js — all page behaviour
   ---------------------------------------------------------
   1. Loading screen
   2. Theme toggle (saved in localStorage)
   3. Typing animation
   4. Network canvas background
   5. Navbar: sticky, mobile menu, active link
   6. Scroll progress + back to top
   7. Reveal on scroll + skill bars + counters
   8. Project filters
   9. GitHub heatmap
   10. Contact form
   ========================================================= */

(function () {
  "use strict";

  /* =======================================================
     CONFIG — the only thing you need to edit here
     -------------------------------------------------------
     Paste your Formspree form ID between the quotes.
     From https://formspree.io/f/abcdwxyz  →  use "abcdwxyz"

     Leave it empty and the form falls back to opening the
     visitor's mail app instead. Both work; Formspree is nicer.
     ======================================================= */
  const FORMSPREE_ID = "mykrnzve";
  const MY_EMAIL     = "aheel2002@gmail.com";

  const $  = (s, ctx = document) => ctx.querySelector(s);
  const $$ = (s, ctx = document) => Array.from(ctx.querySelectorAll(s));
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- 1. LOADING SCREEN ---------- */
  (function loader() {
    const box  = $("#loader");
    const fill = $("#loaderFill");
    const pct  = $("#loaderPct");
    const txt  = $("#loaderText");
    if (!box) return;

    const steps = [
      "Initializing secure connection",
      "Verifying certificates",
      "Loading modules",
      "Access granted"
    ];

    let n = 0;
    const timer = setInterval(() => {
      n = Math.min(100, n + Math.random() * 18 + 6);
      fill.style.width = n + "%";
      pct.textContent = Math.floor(n);
      txt.textContent = steps[Math.min(steps.length - 1, Math.floor(n / 26))];

      if (n >= 100) {
        clearInterval(timer);
        setTimeout(() => {
          box.classList.add("is-done");
          document.body.classList.remove("is-locked");
        }, 350);
      }
    }, 160);

    document.body.classList.add("is-locked");
  })();

  /* ---------- 2. THEME TOGGLE ---------- */
  (function theme() {
    const root = document.documentElement;
    const btn  = $("#themeToggle");
    const saved = localStorage.getItem("theme");

    if (saved) {
      root.setAttribute("data-theme", saved);
    } else if (window.matchMedia("(prefers-color-scheme: light)").matches) {
      root.setAttribute("data-theme", "light");
    }

    btn && btn.addEventListener("click", () => {
      const next = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
      root.setAttribute("data-theme", next);
      localStorage.setItem("theme", next);
    });
  })();

  /* ---------- 3. TYPING ANIMATION ---------- */
  (function typing() {
    const out = $("#typed");
    if (!out) return;

    const words = [
      "Cyber Security student",
      "Aspiring security analyst",
      "Programmer",
      "Ethical hacking learner"
    ];

    let w = 0, c = 0, deleting = false;

    function tick() {
      const word = words[w];
      c += deleting ? -1 : 1;
      out.textContent = word.slice(0, c);

      let wait = deleting ? 45 : 85;

      if (!deleting && c === word.length) { wait = 1600; deleting = true; }
      else if (deleting && c === 0) { deleting = false; w = (w + 1) % words.length; wait = 300; }

      setTimeout(tick, wait);
    }
    tick();
  })();

  /* ---------- 4. NETWORK CANVAS ---------- */
  (function network() {
    const cv = $("#netCanvas");
    if (!cv || reduceMotion) return;

    const ctx = cv.getContext("2d");
    let nodes = [], w = 0, h = 0, mouse = { x: -999, y: -999 }, raf;

    function accent() {
      return getComputedStyle(document.documentElement).getPropertyValue("--primary").trim() || "#00E5FF";
    }

    function size() {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = cv.clientWidth; h = cv.clientHeight;
      cv.width = w * dpr; cv.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      const count = Math.min(90, Math.round((w * h) / 16000));
      nodes = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.35,
        vy: (Math.random() - 0.5) * 0.35,
        r: Math.random() * 1.6 + 0.8
      }));
    }

    function draw() {
      ctx.clearRect(0, 0, w, h);
      const col = accent();

      for (const n of nodes) {
        n.x += n.vx; n.y += n.vy;
        if (n.x < 0 || n.x > w) n.vx *= -1;
        if (n.y < 0 || n.y > h) n.vy *= -1;

        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
        ctx.fillStyle = col;
        ctx.globalAlpha = 0.5;
        ctx.fill();
      }

      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x;
          const dy = nodes[i].y - nodes[j].y;
          const d  = Math.hypot(dx, dy);
          if (d < 130) {
            ctx.beginPath();
            ctx.moveTo(nodes[i].x, nodes[i].y);
            ctx.lineTo(nodes[j].x, nodes[j].y);
            ctx.strokeStyle = col;
            ctx.globalAlpha = (1 - d / 130) * 0.18;
            ctx.lineWidth = 1;
            ctx.stroke();
          }
        }

        const mx = nodes[i].x - mouse.x;
        const my = nodes[i].y - mouse.y;
        const md = Math.hypot(mx, my);
        if (md < 170) {
          ctx.beginPath();
          ctx.moveTo(nodes[i].x, nodes[i].y);
          ctx.lineTo(mouse.x, mouse.y);
          ctx.strokeStyle = col;
          ctx.globalAlpha = (1 - md / 170) * 0.35;
          ctx.stroke();
        }
      }

      ctx.globalAlpha = 1;
      raf = requestAnimationFrame(draw);
    }

    window.addEventListener("resize", size);
    window.addEventListener("mousemove", e => {
      const box = cv.getBoundingClientRect();
      mouse.x = e.clientX - box.left;
      mouse.y = e.clientY - box.top;
    });
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) cancelAnimationFrame(raf);
      else raf = requestAnimationFrame(draw);
    });

    size();
    draw();
  })();

  /* ---------- 5. NAVBAR ---------- */
  (function nav() {
    const bar    = $("#nav");
    const burger = $("#burger");
    const links  = $("#navLinks");

    window.addEventListener("scroll", () => {
      bar.classList.toggle("is-stuck", window.scrollY > 20);
    }, { passive: true });

    burger && burger.addEventListener("click", () => {
      const open = links.classList.toggle("is-open");
      burger.classList.toggle("is-open", open);
      burger.setAttribute("aria-expanded", String(open));
    });

    $$(".nav__link").forEach(a => a.addEventListener("click", () => {
      links.classList.remove("is-open");
      burger.classList.remove("is-open");
      burger.setAttribute("aria-expanded", "false");
    }));

    // active link while scrolling
    const sections = $$("main section[id]");
    const navLinks = $$(".nav__link");

    function sync() {
      const y = window.scrollY + 120;
      let current = sections[0] ? sections[0].id : "home";
      for (const s of sections) if (s.offsetTop <= y) current = s.id;
      navLinks.forEach(a => a.classList.toggle("is-active", a.getAttribute("href") === "#" + current));
    }
    window.addEventListener("scroll", sync, { passive: true });
    sync();
  })();

  /* ---------- 6. PROGRESS + BACK TO TOP ---------- */
  (function scrollBits() {
    const bar = $("#progress");
    const top = $("#toTop");
    const glow = $("#cursorGlow");

    window.addEventListener("scroll", () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      bar.style.width = (max > 0 ? (window.scrollY / max) * 100 : 0) + "%";
      top.classList.toggle("is-shown", window.scrollY > 500);
    }, { passive: true });

    top.addEventListener("click", () => window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" }));

    if (glow && !reduceMotion && window.matchMedia("(pointer: fine)").matches) {
      window.addEventListener("mousemove", e => {
        glow.style.opacity = "1";
        glow.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
      });
    }
  })();

  /* ---------- 7. REVEAL, BARS, COUNTERS ---------- */
  (function reveals() {
    const io = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        const el = entry.target;
        el.classList.add("is-in");

        // skill bars
        $$(".bar__track span", el).forEach(s => { s.style.width = s.dataset.w + "%"; });

        // counters
        const num = el.querySelector(".count");
        if (num && !num.dataset.done) {
          num.dataset.done = "1";
          const target = +num.dataset.target;
          const dur = 1400;
          const start = performance.now();
          (function step(now) {
            const p = Math.min(1, (now - start) / dur);
            num.textContent = Math.round(target * (1 - Math.pow(1 - p, 3)));
            if (p < 1) requestAnimationFrame(step);
          })(start);
        }

        obs.unobserve(el);
      });
    }, { threshold: 0.15, rootMargin: "0px 0px -40px 0px" });

    $$(".reveal").forEach(el => io.observe(el));

    // bars live inside .about__skills — make sure they fire too
    const skills = $(".about__skills");
    if (skills) io.observe(skills);
  })();

  /* ---------- 8. PROJECT FILTERS ---------- */
  (function filters() {
    const box = $("#filters");
    if (!box) return;

    box.addEventListener("click", e => {
      const btn = e.target.closest(".filter");
      if (!btn) return;

      $$(".filter", box).forEach(b => b.classList.remove("is-active"));
      btn.classList.add("is-active");

      const want = btn.dataset.filter;
      $$(".proj").forEach(card => {
        const show = want === "all" || card.dataset.tag === want;
        card.classList.toggle("is-hidden", !show);
      });
    });
  })();

  /* ---------- 9. GITHUB HEATMAP (visual placeholder) ---------- */
  (function heat() {
    const box = $("#heat");
    if (!box) return;
    let html = "";
    for (let i = 0; i < 7 * 30; i++) {
      const r = Math.random();
      const lvl = r > 0.92 ? 4 : r > 0.78 ? 3 : r > 0.6 ? 2 : r > 0.35 ? 1 : 0;
      html += `<i data-lvl="${lvl}"></i>`;
    }
    box.innerHTML = html;
  })();

  /* ---------- 10. CONTACT FORM ---------- */
  (function form() {
    const btn  = $("#sendBtn");
    const note = $("#formNote");
    if (!btn) return;

    const fields = {
      name:    $("#cName"),
      email:   $("#cEmail"),
      subject: $("#cSubject"),
      message: $("#cMessage")
    };

    function say(msg, ok) {
      note.textContent = msg;
      note.className = "form-note " + (ok ? "is-ok" : "is-bad");
    }

    btn.addEventListener("click", () => {
      Object.values(fields).forEach(f => f.parentElement.classList.remove("has-error"));

      const missing = Object.entries(fields).filter(([, f]) => !f.value.trim());
      if (missing.length) {
        missing.forEach(([, f]) => f.parentElement.classList.add("has-error"));
        say("Fill in every field before sending.", false);
        return;
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email.value)) {
        fields.email.parentElement.classList.add("has-error");
        say("That email address doesn't look right.", false);
        return;
      }

      // ---- No Formspree ID set: open the visitor's mail app instead ----
      if (!FORMSPREE_ID) {
        const body = `Name: ${fields.name.value}\nEmail: ${fields.email.value}\n\n${fields.message.value}`;
        window.location.href =
          `mailto:${MY_EMAIL}?subject=${encodeURIComponent(fields.subject.value)}&body=${encodeURIComponent(body)}`;
        say("Opening your mail app with the message ready to send.", true);
        return;
      }

      // ---- Formspree ----
      const original = btn.textContent;
      btn.disabled = true;
      btn.textContent = "Sending…";
      say("Sending your message…", true);

      fetch(`https://formspree.io/f/${FORMSPREE_ID}`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify({
          name:     fields.name.value,
          email:    fields.email.value,
          _replyto: fields.email.value,
          _subject: fields.subject.value,
          subject:  fields.subject.value,
          message:  fields.message.value
        })
      })
      .then(res => {
        if (!res.ok) throw new Error("rejected");
        Object.values(fields).forEach(f => { f.value = ""; });
        say("Message sent. I'll get back to you soon.", true);
      })
      .catch(() => {
        say(`Couldn't send that. Email me directly at ${MY_EMAIL}.`, false);
      })
      .finally(() => {
        btn.disabled = false;
        btn.textContent = original;
      });
    });
  })();

  /* ---------- YEAR ---------- */
  const y = $("#year");
  if (y) y.textContent = new Date().getFullYear();

})();
