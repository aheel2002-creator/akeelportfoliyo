# Sahith Aheel — Cyber Security Portfolio

A single-page portfolio website. Every nav item smooth-scrolls to its section — no page reloads, no build step, no `npm install`.

---

## Folder structure

```
saheel-portfolio/
│
├── index.html              ← the whole page structure
│
├── css/
│   └── style.css           ← all styling, dark + light themes
│
├── js/
│   ├── projects.js         ← YOUR CONTENT: projects & blog posts (edit this first)
│   └── main.js             ← all behaviour: loader, theme, typing, canvas, scroll
│
├── assets/
│   ├── images/
│   │   └── profile.jpg     ← your photo
│   └── cv/
│       └── CV.pdf          ← the file the "Download CV" button hands over
│
└── README.md               ← this file
```

---

## How to run it — step by step

### Option 1 — Just open it (10 seconds)

1. Download / unzip the `saheel-portfolio` folder somewhere you'll find it, e.g. `Desktop`.
2. Open the folder.
3. Double-click **`index.html`**.

It opens in your default browser and everything works. That's it.

### Option 2 — Run a local server (recommended while editing)

A local server avoids browser security quirks and gives you a proper `http://` address.

**If you have Python** (most computers do):

1. Open Terminal / Command Prompt.
2. Move into the folder:
   ```bash
   cd path/to/saheel-portfolio
   ```
   Windows tip: open the folder, click the address bar, type `cmd`, press Enter — you're already in the right place.
3. Start the server:
   ```bash
   python -m http.server 5500
   ```
   (If `python` isn't recognised, try `python3 -m http.server 5500`.)
4. Open your browser at **http://localhost:5500**
5. Press `Ctrl + C` in the terminal to stop it.

**If you have Node.js:**

```bash
cd path/to/saheel-portfolio
npx serve
```
Then open the address it prints (usually http://localhost:3000).

**If you use VS Code (easiest for editing):**

1. Install the **Live Server** extension.
2. Open the `saheel-portfolio` folder in VS Code (`File → Open Folder`).
3. Right-click `index.html` → **Open with Live Server**.
4. The page reloads automatically every time you save a file.

---

## Editing your content

| What you want to change | Where |
|---|---|
| Projects (title, description, tech, GitHub link) | `js/projects.js` → the `PROJECTS` array |
| Blog posts | `js/projects.js` → the `POSTS` array |
| Typing animation words | `js/main.js` → the `words` array in section 3 |
| Your bio, contact details, skill percentages | `index.html` → the About and Contact sections |
| Colours | `css/style.css` → the `:root` block at the top |
| Your photo | Replace `assets/images/profile.jpg` (keep the same filename) |
| Your CV | Replace `assets/cv/CV.pdf` (keep the same filename) |
| Stat counters (12+, 8+, 20+, 3+) | `index.html` → `data-target` values in the stats section |

**Links to fill in.** These currently point to generic placeholders — search `index.html` and `js/projects.js` for `https://github.com/` and replace with your real profiles:

- GitHub profile and per-project repo links
- Instagram and Facebook
- LinkedIn is set to `linkedin.com/in/sahith-akeel` — correct it if your actual URL differs
- The displayed name is **Sahith Aheel** (from your CV). If you prefer **M.A. Saheel**, change it in `index.html` (hero, About info card, footer) and in the `<title>` tag.

---

## Making the contact form send email (Formspree)

The code is already written. You only need to paste in one ID.

**Step 1 — Create the form**

1. Go to **formspree.io** and sign up with `aheel2002@gmail.com` (free plan: 50 submissions a month).
2. Click **+ New Form**.
3. Name it `Portfolio Contact`, set the send-to address to your email, click **Create Form**.
4. Formspree shows you an endpoint like:
   ```
   https://formspree.io/f/xbldwqrz
   ```
   The last part — `xbldwqrz` — is your **form ID**. Copy it.

**Step 2 — Paste it into the code**

Open `js/main.js`. Near the top (line ~28) you'll see:

```js
const FORMSPREE_ID = "";
```

Put your ID between the quotes:

```js
const FORMSPREE_ID = "xbldwqrz";
```

Save. That's the whole change — the form now POSTs to Formspree, clears itself on success, and shows an error message if the send fails.

> While `FORMSPREE_ID` is empty, the form opens the visitor's mail app instead. So it never looks broken, whichever state it's in.

**Step 3 — Test it**

1. Run the site (`python -m http.server 5500`) and open http://localhost:5500
2. Fill in the contact form and click **Send message**.
3. First submission only: Formspree emails you a confirmation link. Click it to activate the form.
4. Send a second test message — it should land in your inbox within a minute.

**If it doesn't work**

- *"Form not found"* → the ID is wrong or has a typo. Re-copy it from your Formspree dashboard.
- *Nothing happens* → open the browser console (`F12` → Console) and read the error.
- *Works on localhost, fails when deployed* → in Formspree, open your form's settings and add your live domain to the allowed domains list.
- Formspree's free plan blocks submissions past 50/month; check your dashboard if things stop arriving.

---

## Live GitHub statistics

The GitHub numbers and calendar are placeholders. To make them real, replace the `.gh` block in `index.html` with:

```html
<img src="https://github-readme-stats.vercel.app/api?username=YOUR_USERNAME&show_icons=true&theme=dark" alt="GitHub stats">
<img src="https://ghchart.rshah.org/00E5FF/YOUR_USERNAME" alt="Contribution chart">
```

Swap `YOUR_USERNAME` for your GitHub username. These load as images, so no API key is needed.

---

## Putting it online free (Netlify)

### Method A — Drag and drop (fastest, ~30 seconds)

1. Go to **app.netlify.com/drop**
2. Drag the whole `saheel-portfolio` **folder** from your file explorer onto that page.
   Drag the folder itself, not the files inside it, and not the `.zip`.
3. Wait for the upload bar. Netlify gives you a live URL like
   `https://sparkly-marzipan-8f2a1c.netlify.app`
4. Click **Site configuration → Change site name** to make it something like
   `sahith-aheel.netlify.app`

Done — it's live worldwide with HTTPS.

The catch: to update the site you drag the folder again. Fine for now, annoying later.

### Method B — Connect GitHub (updates itself)

Once this is on GitHub, every push redeploys automatically.

**Put the code on GitHub first:**

1. Create a repo at github.com/new called `portfolio`. Don't tick "Add a README".
2. In your terminal:
   ```bash
   cd path/to/saheel-portfolio
   git init
   git add .
   git commit -m "Portfolio site"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/portfolio.git
   git push -u origin main
   ```

**Then connect Netlify:**

1. Sign in at app.netlify.com (choose "Sign up with GitHub" — it saves a step).
2. **Add new site → Import an existing project → GitHub**.
3. Authorise Netlify, then pick your `portfolio` repo.
4. Build settings — this is a plain static site, so leave them mostly empty:
   - **Build command:** *(leave blank)*
   - **Publish directory:** `.` (a single dot)
   - **Branch:** `main`
5. Click **Deploy**.

From now on, `git add . && git commit -m "update" && git push` publishes your changes in about 30 seconds.

### Adding your own domain

If you buy a domain (e.g. `sahithaheel.com`), go to **Domain management → Add a domain** in Netlify and follow the DNS instructions. HTTPS is issued automatically and free.

### Other free hosts

**GitHub Pages** — push to a repo, then `Settings → Pages → Branch: main / root`. Lives at `https://yourusername.github.io/portfolio`.

**Vercel** — run `npx vercel` inside the folder, or import the repo at vercel.com.

---

## What's included

Loading screen · scroll progress bar · sticky navbar with active-section highlighting · mobile menu · dark/light toggle saved between visits · animated network background · typing animation · cursor glow · animated counters · skill bars · scroll reveals · project filters · back-to-top button · responsive down to phone size · reduced-motion support for accessibility.
